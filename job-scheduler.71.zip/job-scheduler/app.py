from flask import Flask, render_template, request, redirect

app = Flask(__name__)
jobs = []  # Job list memory store

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/add_job', methods=['POST'])
def add_job():
    job_id = request.form['id']
    deadline = int(request.form['deadline'])
    profit = int(request.form['profit'])
    jobs.append({'id': job_id, 'deadline': deadline, 'profit': profit})
    return redirect('/')

@app.route('/schedule')
def schedule():
    scheduled_jobs, total_profit = schedule_jobs(jobs)
    return render_template('result.html', jobs=scheduled_jobs, profit=total_profit)

def schedule_jobs(jobs):
    jobs.sort(key=lambda x: x['profit'], reverse=True)
    max_deadline = max(job['deadline'] for job in jobs)
    slots = [False] * (max_deadline + 1)
    result = []
    profit = 0
    for job in jobs:
        for t in range(job['deadline'], 0, -1):
            if not slots[t]:
                slots[t] = True
                result.append(job['id'])
                profit += job['profit']
                break
    return result, profit

if __name__ == '__main__':
    app.run(debug=True)